
/**
 * Customer class keeps track of customer personal info
 * @author Gabriela, Safina, Mel
 * Cited Code:
 * Dathan B, Ramnath S. 24 Mar 2015. Source Code.  Class Project 2 Iteration 2.  
 * https://metrostate.learn.minnstate.edu/d2l/le/content/4940178/viewContent/43082126/View
 */
import java.io.Serializable;

public class Customer implements Serializable {
	private String name;
	private String address;
	private String phone;
	private String id;
	private static final long serialVersionUID = 1L;

	private static final String CUSTOMER_STRING = "G";

	/**
	 * Creates constructor for Customer
	 * 
	 * @param name    name of customer
	 * @param address address of customer
	 * @param phone   phone of customer
	 */

	public Customer(String name, String address, String phone) {

		this.name = name;
		this.address = address;
		this.phone = phone;
		id = CUSTOMER_STRING + (CustomerIDServer.instance().getId());

	}

	/**
	 * checks if id equals what was passed in
	 * 
	 * @param id
	 */
	public boolean equals(String id) {
		return this.id.equals(id);
	}

	/**
	 * getName() gets customer name
	 * 
	 * @return name
	 */
	public String getName() {
		return name;
	}

	/**
	 * setsName() sets name
	 * 
	 * @param name name of customer
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * getAddress() gets customer address
	 * 
	 * @return address address of customer
	 */
	public String getAddress() {
		return address;
	}

	/**
	 * setAddress() sets the address of customer
	 * 
	 * @param address address of customer
	 */
	public void setAddress(String address) {
		this.address = address;
	}

	/**
	 * getPhone() get phone number of customer
	 * 
	 * @return phone phone number of customer
	 */
	public String getPhone() {
		return phone;
	}

	/**
	 * sets phone number of customer
	 * 
	 * @param phone number of customer
	 */
	public void setPhone(String phone) {
		this.phone = phone;
	}

	/**
	 * getId() gets if of customer
	 * 
	 * @return id of customer
	 */
	public String getId() {
		return id;
	}

	/**
	 * sets id of customer
	 * 
	 * @param id of customer
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * toString() gives a string representation of customer
	 * 
	 * @return customer profile
	 */
	@Override
	public String toString() {
		return "Customer [name=" + this.getName() + 
				", address=" + this.getAddress() + ", phone=" + this.getPhone()
				+ ", id=" + this.getId() + "]";
	}

}
