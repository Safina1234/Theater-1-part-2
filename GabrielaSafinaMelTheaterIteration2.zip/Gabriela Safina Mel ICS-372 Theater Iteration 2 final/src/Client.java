import java.io.Serializable;

/**
 * Client class holds client info for client who put on shows
 * 
 * @author Gabriela, Safina, Mel Cited Code: Dathan B, Ramnath S. 24 Mar 2015.
 *         Source Code. Class Project 2 Iteration 2.
 *         https://metrostate.learn.minnstate.edu/d2l/le/content/4940178/viewContent/43082126/View
 *
 */
public class Client implements Serializable {

	private String name;
	private String address;
	private String phone;
	private String id;
	private double balance = 0;
	private static final String CLIENT_STRING = "C";
	double sumBalance = 0;

	public Client(String name, String address, String phone) {

		this.name = name;
		this.address = address;
		this.phone = phone;
		id = CLIENT_STRING + (ClientIDServer.instance().getId());
	}

	/**
	 * increaseClientBalance() adds price to client balance
	 * 
	 * @param price price of ticket total
	 * 
	 * @param price price of ticket
	 */
	public void increaseClientBalance(double price) {
		balance = balance + price;
		System.out.println(balance);
	}

	/**
	 * payClientBalance() method pays client a designated amt of money
	 * 
	 * @param price price from tickets purchased
	 * 
	 */
	public void payClientBalance(double price) {
		balance -= price;
		System.out.print(price);
	}

	/**
	 * equals() method compares client id
	 * 
	 * @param id client id
	 * @return True if client id match; else false
	 */
	public boolean equals(String id) {

		return this.id.equals(id);
	}

	/**
	 * getName() method gets the name of client
	 * 
	 * @return the name name of client
	 */
	public String getName() {
		return name;
	}

	/**
	 * setName() set client name
	 * 
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * getAddress() gets client address
	 * 
	 * @return the address of client
	 */
	public String getAddress() {
		return address;
	}

	/**
	 * setAddress() sets address of client
	 * 
	 * @param address the address to set
	 */
	public void setAddress(String address) {
		this.address = address;
	}

	/**
	 * getPhone() gets client phone number
	 * 
	 * @return the phone number of client
	 */
	public String getPhone() {
		return phone;
	}

	/**
	 * setPhone() set phone number of client
	 * 
	 * @param phone of client
	 */
	public void setPhone(String phone) {
		this.phone = phone;
	}

	/**
	 * getId() gets client id
	 * 
	 * @return the id client id
	 */
	public String getId() {
		return id;
	}

	/**
	 * setID() sets client id
	 * 
	 * @param id the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * getBalance() gets client balance
	 * 
	 * @return the balance of client
	 */
	public double getBalance() {
		return balance;
	}

	/**
	 * toString() returns string representation of client
	 * 
	 * @return client profile info
	 */
	@Override
	public String toString() {
		return "Client [name=" + name + ", address=" + address + 
				", phone=" + phone + ", id=" + id + ", balance="
				+ balance + "]";
	}

}
