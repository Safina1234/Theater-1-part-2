
/**
 * CreditCard class holds all of the credit card info of customers
 * @author Gabriela, Safina, Mel
 * Cited Code:
 * Dathan B, Ramnath S. 24 Mar 2015. Source Code.  Class Project 2 Iteration 2.  
 * https://metrostate.learn.minnstate.edu/d2l/le/content/4940178/viewContent/43082126/View
 */
import java.io.Serializable;
import java.util.Iterator;
import java.util.LinkedList;

public class CreditCard implements Serializable {

	private static final long serialVersionUID = 1L;
	private String cardNumber;
	private String id;
	private LinkedList<CreditCard> listOfCard = new LinkedList<CreditCard>();

	/**
	 * getId() gets ID of customer
	 * 
	 * @return id
	 */
	public String getId() {
		return id;
	}

	/**
	 * setID() sets the id passed through
	 * 
	 * @param id customer id
	 */
	public void setId(String id) {
		this.id = id;
	}

	private String date;

	/**
	 * creates CreditCard object
	 * 
	 * @param id         id number of customer
	 * @param cardNumber credit card number of customer
	 * @param date       of credit card exp
	 */
	public CreditCard(String id, String cardNumber, String date) {
		super();
		this.id = id;
		this.cardNumber = cardNumber;
		this.date = date;
	}

	/**
	 * getCardNumber() returns cardNumber
	 * 
	 * @return cardNumber customer credit card number
	 */
	public String getCardNumber() {
		return cardNumber;
	}

	/**
	 * setCardNumber() sets cardNumber
	 * 
	 * @param cardNumber customer credit card number
	 */
	public void setCardNumber(String cardNumber) {
		this.cardNumber = cardNumber;
	}

	/**
	 * getDate() returns date
	 * 
	 * @param date date of expiration
	 */
	public String getDate() {
		return date;
	}

	/**
	 * sets date of credit expiration
	 * 
	 * @param date date of expiration
	 */
	public void setDate(String date) {
		this.date = date;
	}

	@Override
	public String toString() {
		return "CreditCard [cardNumber=" + cardNumber + ", date=" + date + "]";
	}

	/**
	 * searches list for card
	 * 
	 * @param clientId id of client
	 * @return card all credit card info from customer profile
	 */
	public CreditCard search(String clientId) {
		for (Iterator<CreditCard> iterator = listOfCard.iterator(); iterator.hasNext();) {
			CreditCard card = (CreditCard) iterator.next();
			if (card.getCardNumber().equals(clientId)) {
				return card;
			}
		}
		return null;
	}

}
