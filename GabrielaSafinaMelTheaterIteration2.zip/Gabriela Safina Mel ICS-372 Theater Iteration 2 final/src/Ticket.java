
/**
 * Ticket class is where ticket object is made and ticket info comes in
 * @author Gabriela, Safina, Mel
 * Cited Code:
 * Dathan B, Ramnath S. 24 Mar 2015. Source Code.  Class Project 2 Iteration 2.  
 * https://metrostate.learn.minnstate.edu/d2l/le/content/4940178/viewContent/43082126/View
 */
import java.io.Serializable;
import java.io.*;

public abstract class Ticket implements Serializable {

	private int quantity;
	private String customerID;
	private String creditCardNum;
	private String showDate;
	String id;
	String ticketLabel;
	double price;
	private static final String TICKET_STRING = "C";

	public Ticket(int quantity, String customerID, String creditCardNum, String showDate, double price) {

		this.quantity = quantity;
		this.customerID = customerID;
		this.creditCardNum = creditCardNum;
		this.showDate = showDate;
		this.price = price;
		id = TICKET_STRING + (ClientIDServer.instance().getId());
	}

	public double getPrice() {
		return price;
	}
	/*
	 * checks if the id is equal to the current id
	 * 
	 * @param id returns a boolean depending if the ids are equal
	 */

	public boolean equals(String id) {

		return this.id.equals(id);
	}

//Getters and Setters for all ticket attributes
	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public String getCustomerID() {
		return customerID;
	}

	public void setCustomerID(String customerID) {
		this.customerID = customerID;
	}

	public String getCreditCardNum() {
		return creditCardNum;
	}

	public void setCreditCardNum(String creditCardNum) {
		this.creditCardNum = creditCardNum;
	}

	public String getShowDate() {
		return showDate;
	}

	public void setShowDate(String showDate) {
		this.showDate = showDate;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	/**
	 * toString() represents the string representation of the ticket object returns
	 * the string representation
	 **/

	@Override
	public String toString() {
		return "Ticket [quantity=" + quantity + ", customerID=" + 
	customerID + ", credit card number=" + creditCardNum
				+ "show date: " + showDate;
	}

}
