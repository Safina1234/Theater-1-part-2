
/**
 * CreditCardList class stores a list of credit cards
 * @author Gabriela, Safina, Mel
 * Cited Code:
 * Dathan B, Ramnath S. 24 Mar 2015. Source Code.  Class Project 2 Iteration 2.  
 * https://metrostate.learn.minnstate.edu/d2l/le/content/4940178/viewContent/43082126/View 
 **/
import java.io.IOException;
import java.io.Serializable;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

public class CreditCardList implements Serializable {

	private static final long serialVersionUID = 1L;
	private List<CreditCard> listOfCreditCards = new LinkedList<CreditCard>();
	private static CreditCardList catalog;

	/*
	 * Private constructor for singleton pattern
	 * 
	 */
	private CreditCardList() {
	}

	/**
	 * Supports the singleton pattern
	 * 
	 * @return the singleton object
	 */
	public static CreditCardList instance() {
		if (catalog == null) {
			return (catalog = new CreditCardList());
		} else {
			return catalog;
		}
	}

	/**
	 * Checks whether a book with a given book id exists.
	 * 
	 * @param bookId the id of the book
	 * @return true iff the book exists
	 * 
	 */
	public CreditCard search(String clientID) {
		for (Iterator iterator = listOfCreditCards.iterator(); iterator.hasNext();) {
			CreditCard card = (CreditCard) iterator.next();
			if (card.getId().equals(clientID)) {
				return card;
			}
		}
		return null;
	}

	/**
	 * Removes a book from the catalog
	 * 
	 * @param bookId book id
	 * @return true iff book could be removed
	 */
	public boolean removeCard(String clientID, String cardNumber) {
		CreditCard card = search(cardNumber);
		int i = 0;
		for (CreditCard c : listOfCreditCards) {
			if (listOfCreditCards.contains(clientID)) {
				i++;
			}
		}
		if (i > 1) {
			if (card.getId().equals(clientID)) {
				return listOfCreditCards.remove(card);
			}
		}
		return false;

	}

	/**
	 * Inserts a book into the collection
	 * 
	 * @param book the book to be inserted
	 * @return true iff the book could be inserted. Currently always true
	 */
	public boolean addCard(CreditCard card) {
		listOfCreditCards.add(card);
		return true;
	}

	/**
	 * Returns an iterator to all books
	 * 
	 * @return iterator to the collection
	 */
	public Iterator<CreditCard> getCards() {
		return listOfCreditCards.iterator();
	}

	/*
	 * Supports serialization
	 * 
	 * @param output the stream to be written to
	 */
	private void writeObject(java.io.ObjectOutputStream output) {
		try {
			output.defaultWriteObject();
			output.writeObject(catalog);
		} catch (IOException ioe) {
			System.out.println(ioe);
		}
	}

	/*
	 * Supports serialization
	 * 
	 * @param input the stream to be read from
	 */
	private void readObject(java.io.ObjectInputStream input) {
		try {
			if (catalog != null) {
				return;
			} else {
				input.defaultReadObject();
				if (catalog == null) {
					catalog = (CreditCardList) input.readObject();
				} else {
					input.readObject();
				}
			}
		} catch (IOException ioe) {
			System.out.println("in Catalog readObject \n" + ioe);
		} catch (ClassNotFoundException cnfe) {
			cnfe.printStackTrace();
		}
	}

	/**
	 * String form of the collection
	 * 
	 */
	public String toString() {
		return listOfCreditCards.toString();
	}
}
