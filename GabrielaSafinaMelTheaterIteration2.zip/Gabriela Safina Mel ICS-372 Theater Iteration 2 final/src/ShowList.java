/**
* ShowList() stores a list of shows
 * @author Gabriela, Safina, Mel
 * Cited Code:
 * Dathan B, Ramnath S. 24 Mar 2015. Source Code.  Class Project 2 Iteration 2.  
 * https://metrostate.learn.minnstate.edu/d2l/le/content/4940178/viewContent/43082126/View
 */
import java.io.IOException;
import java.io.Serializable;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

public class ShowList implements Serializable {

	private static final long serialVersionUID = 1L;
	private List<Show> listOfShows = new LinkedList<Show>();
	private static ShowList catalog;

	/*
	 * Private constructor for singleton pattern
	 * 
	 */
	private ShowList() {
	}

	/**
	 * Supports the singleton pattern
	 * 
	 * @return the singleton object
	 */
	public static ShowList instance() {
		if (catalog == null) {
			return (catalog = new ShowList());
		} else {
			return catalog;
		}
	}

	/**
	 * Checks whether a book with a given book id exists.
	 * 
	 * @param bookId the id of the book
	 * @return true iff the book exists
	 * 
	 */
	public Show search(String clientID) {
		for (Iterator iterator = listOfShows.iterator(); iterator.hasNext();) {
			Show show = (Show) iterator.next();
			if (show.getClientID().equals(clientID)) {
				return show;
			}
		}
		return null;
	}

	/**
	 * Removes a book from the catalog
	 * 
	 * @param bookId book id
	 * @return true iff book could be removed
	 */
	public boolean removeShows(String clientID) {
		Show show = search(clientID);
		if (show.getClientID().equals(clientID)) {
			return listOfShows.remove(show);
		}
		return false;

	}

	/**
	 * Inserts a book into the collection
	 * 
	 * @param book the book to be inserted
	 * @return true iff the book could be inserted. Currently always true
	 */
	public boolean insertShow(Show show) {
		listOfShows.add(show);
		return true;
	}

	/**
	 * Returns an iterator to all books
	 * 
	 * @return iterator to the collection
	 */
	public Iterator<Show> getShows() {
		return listOfShows.iterator();
	}

	/**
	 * 
	 * @param date
	 * @return
	 */
	public Show searchByDate(String date) {
		for (Iterator<Show> iterator = listOfShows.iterator(); iterator.hasNext();) {
			Show show = (Show) iterator.next();
			if (show.getStartDate().equals(date)) {
				return show;
			}
		}
		return null;
	}

	/*
	 * Supports serialization
	 * 
	 * @param output the stream to be written to
	 */
	private void writeObject(java.io.ObjectOutputStream output) {
		try {
			output.defaultWriteObject();
			output.writeObject(catalog);
		} catch (IOException ioe) {
			System.out.println(ioe);
		}
	}

	/*
	 * Supports serialization
	 * 
	 * @param input the stream to be read from
	 */
	private void readObject(java.io.ObjectInputStream input) {
		try {
			if (catalog != null) {
				return;
			} else {
				input.defaultReadObject();
				if (catalog == null) {
					catalog = (ShowList) input.readObject();
				} else {
					input.readObject();
				}
			}
		} catch (IOException ioe) {
			System.out.println("in Catalog readObject \n" + ioe);
		} catch (ClassNotFoundException cnfe) {
			cnfe.printStackTrace();
		}
	}

	/**
	 * String form of the collection
	 * 
	 */
	public String toString() {
		return listOfShows.toString();
	}
}
