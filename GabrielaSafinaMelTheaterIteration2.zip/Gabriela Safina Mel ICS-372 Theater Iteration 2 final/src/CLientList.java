
/**
 * ClientList class holds all of the clients in a list
 * @author Gabriela, Safina, Mel
 * Cited Code:
 * Dathan B, Ramnath S. 24 Mar 2015. Source Code.  Class Project 2 Iteration 2.  
 * https://metrostate.learn.minnstate.edu/d2l/le/content/4940178/viewContent/43082126/View
 */
import java.io.IOException;
import java.io.Serializable;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

public class CLientList implements Serializable {

	private static final long serialVersionUID = 1L;

	private List<Client> clients = new LinkedList<Client>();
	private static CLientList clientList;

	/*
	 * Private constructor for singleton pattern
	 * 
	 */
	private CLientList() {
	}

	/**
	 * Supports the singleton pattern
	 * 
	 * @return the singleton object
	 */
	public static CLientList instance() {
		if (clientList == null) {
			return (clientList = new CLientList());
		} else {
			return clientList;
		}
	}

	/**
	 * Checks whether a client with a given client id exists.
	 * 
	 * @param clientId the id of the client
	 * @return true if client exists
	 * 
	 */

	public Client search(String clientId) {
		for (Iterator<Client> iterator = clients.iterator(); iterator.hasNext();) {
			Client client = (Client) iterator.next();
			if (client.getId().equals(clientId)) {
				return client;
			}
		}
		return null;
	}

	/**
	 * Inserts a client into the collection
	 * 
	 * @param client
	 * @return true if the client could be inserted. Currently always true
	 */

	public boolean insertClient(Client client) {
		clients.add(client);
		return true;
	}

	/**
	 * deleteClient() Deletes a client into the collection
	 * 
	 * @param client
	 * @return true if the client could be deleted. Currently always true
	 */

	public boolean deleteClient(Client client) {

		clients.remove(client);
		return true;
	}

	/**
	 * displayClientsTheater() Displays the client list
	 * 
	 * @param doesn't return anything
	 */

	public void displayClientsTheater() {

		for (int i = 0; i < clients.size(); i++) {

			System.out.println(clients.get(i));
		}
	}

	/*
	 * Supports serialization
	 * 
	 * @param output the stream to be written to
	 */
	private void writeObject(java.io.ObjectOutputStream output) {
		try {
			output.defaultWriteObject();
			output.writeObject(clientList);
		} catch (IOException ioe) {
			ioe.printStackTrace();
		}
	}

	/*
	 * Supports serialization
	 * 
	 * @param input the stream to be read from
	 */
	private void readObject(java.io.ObjectInputStream input) {
		try {
			if (clientList != null) {
				return;
			} else {
				input.defaultReadObject();
				if (clientList == null) {
					clientList = (CLientList) input.readObject();
				} else {
					input.readObject();
				}
			}
		} catch (IOException ioe) {
			ioe.printStackTrace();
		} catch (ClassNotFoundException cnfe) {
			cnfe.printStackTrace();
		}
	}

	/**
	 * toString() 
	 * @return string representation 
	 * of client collection
	 * 
	 */
	@Override
	public String toString() {
		return clients.toString();
	}
}
