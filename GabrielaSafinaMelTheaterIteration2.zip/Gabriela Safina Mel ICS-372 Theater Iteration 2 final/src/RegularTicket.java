
/**
 * RegularTicket class holds all ticket info for regularly priced tickets
 * @author Gabriela, Safina, Mel
 *
 */
import java.io.*;
import java.io.Serializable;

public class RegularTicket extends Ticket implements Serializable {
	private int quantity;
	private String customerID;
	private String creditCardNum;
	private String showDate;
	String id;
	String ticketLabel;
	double price;
	private static final String TICKET_STRING = "C";

	public RegularTicket(int quantity, String customerID, String creditCardNum, String showDate, double price) {
		super(quantity, customerID, creditCardNum, showDate, price);

		this.customerID = super.getCustomerID();
		this.creditCardNum = super.getCreditCardNum();
		this.showDate = super.getShowDate();
		this.price = super.getPrice();

	}

	/*
	 * checks if the id is equal to the current id
	 * 
	 * @param id returns a boolean depending if the ids are equal
	 */
	public double getPrice() {
		return super.getPrice();
	}

	/**
	 * getQuantity() gets quantity of tickets
	 * 
	 * @return super.getQuantity() ticket quantity
	 * 
	 */
	public int getQuantity() {
		return super.getQuantity();
	}

	/**
	 * getCustomerID() gets customer ID
	 * 
	 * @return super.getCustomerID()
	 */
	public String getCustomerID() {
		return super.getCustomerID();
	}

	/**
	 * setCustomerID() sets customerID
	 * 
	 * @return super.setCustomerID(customerID) constaining customerID
	 */
	public void setCustomerID(String customerID) {
		super.setCustomerID(customerID);
	}

	/**
	 * getCreditCardNum() gets customer credit card number
	 * 
	 * @return super.getCreditCardNum() get customer card number
	 */
	public String getCreditCardNum() {
		return super.getCreditCardNum();
	}

	/**
	 * getShowDate() gets date of show
	 * 
	 * @return super.getShowDate()
	 */
	public String getShowDate() {
		return super.getShowDate();
	}

	/**
	 * getId() gets if
	 * 
	 * @return the id of client
	 */
	public String getId() {
		return super.getId();
	}

	/*
	 * represents the string representation of the ticket object
	 * 
	 * @param returns the string representation
	 */

	@Override
	public String toString() {
		return super.toString();
	}

}
