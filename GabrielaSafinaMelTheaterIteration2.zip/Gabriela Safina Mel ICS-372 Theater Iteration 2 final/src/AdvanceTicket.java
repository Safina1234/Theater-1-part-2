
/**
 * AdvanceTicket() class accounts for tickets purchased in advance that aren't students
 * @author Gabriela Osuna Senn
 * 
 */
import java.io.Serializable;
import java.io.*;

public class AdvanceTicket extends Ticket implements Serializable {
	private int quantity;
	private String customerID;
	private String creditCardNum;
	private String showDate;
	String id;
	String ticketLabel;
	double price;
	private static final String TICKET_STRING = "C";

	public AdvanceTicket(int quantity, String customerID, 
			String creditCardNum, String showDate, double price) {
		super(quantity, customerID, creditCardNum, showDate, price);
		this.customerID = super.getCustomerID();
		this.creditCardNum = super.getCreditCardNum();
		this.showDate = super.getShowDate();
		this.price = super.getPrice() * .7;

	}

	public double getPrice() {
		return super.getPrice() * .70;
	}

	public int getQuantity() {
		return super.getQuantity();
	}

	/**
	 * getCustomerID() allows for customer ID retrieval
	 * 
	 */
	public String getCustomerID() {
		return super.getCustomerID();
	}

	/**
	 * getCreditCardNum() gets the credit card number of customer purshasing the
	 * advance ticket
	 */
	public String getCreditCardNum() {
		return super.getCreditCardNum();
	}

	/**
	 * getShowDate() gets our date of the show for advanced ticket
	 * @return super.getShowDate() date of the show
	 */
	public String getShowDate() {
		return super.getShowDate();
	}

	/** getID() allows for ID of client if to be accessed
	 * @return the id
	 */
	public String getId() {
		return super.getId();
	}

	/**
	 * toString() method provides a string representation of advance ticket info
	 * @return super.toString() string representation of advanced ticket
	 */
	@Override
	public String toString() {
		return super.toString();
	}

}
