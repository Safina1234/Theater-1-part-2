/** this is the TicketList class which creates the TicketList object 
 * this class implements the serializable method 
 * 
 * @author Gabriela, Safina, Mel
 * Cited Code:
 * Dathan B, Ramnath S. 24 Mar 2015. Source Code.  Class Project 2 Iteration 2.  
 * https://metrostate.learn.minnstate.edu/d2l/le/content/4940178/viewContent/43082126/View **/


import java.io.IOException;
import java.io.Serializable;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

public class TicketList implements Serializable {
  
	private static final long serialVersionUID = 1L;
	
	private List<Ticket> tickets = new LinkedList<Ticket>();
	private static TicketList ticketList;
  /*
   * Private constructor for singleton pattern
   * 
   */
  private TicketList() {
  }
  /**
   * Supports the singleton pattern
   * 
   * @return the singleton object
   */
  public static TicketList instance() {
    if (ticketList == null) {
      return (ticketList = new TicketList());
    } else {
      return ticketList;
    }
  }
  /**
   * Checks whether a client with a given client id exists.
   * @param clientId the id of the client
   * @return true if client exists
   * 
   */

public Ticket search(String ticketID) {
    for(
	Iterator<Ticket> iterator = tickets.iterator(); iterator.hasNext(); ) {
    	Ticket ticket = (Ticket) iterator.next();
      if (ticket.getId().equals(ticketID)) {
        return ticket;
      }
    }
    return null;
  }
  /**
   * Inserts a client into the collection
   * @param client
   * @return true if the client could be inserted. Currently always true
   */

public boolean insertTicket(Ticket ticket) {
    tickets.add(ticket);
    return true;
  }

/**
 * Deletes a client into the collection
 * @param client
 * @return true if the client could be deleted. Currently always true
 */
  
  public boolean deleteTicket(Ticket ticket) {
	  
	  tickets.remove(ticket);
	  return true;
  }
  
  /**
   * Displays the client list
   * @param 
   * doesn't return anything
   */
  
  public void displayTicketsTheater() {
	  
	  for(int i=0; i<tickets.size();i++) {
		  
		  System.out.println(tickets.get(i));
	  }
  }
  /**
   * Displays the ticket list based on date
   * @param showDate
   * doesn't return anything
   */
  
  public void displayTicketsDate(String showDate) {
	  for(int i=0; i<tickets.size(); i++) {
		  if(tickets.get(i).getShowDate().equalsIgnoreCase(showDate)) {
			  System.out.println(tickets.get(i));
		  }
	  }
  }
  
  /*
   * Supports serialization
   * @param output the stream to be written to
   */
  private void writeObject(java.io.ObjectOutputStream output) {
    try {
      output.defaultWriteObject();
      output.writeObject(ticketList);
    } catch(IOException ioe) {
      ioe.printStackTrace();
    }
  }
  /*
   * Supports serialization
   *  @param input the stream to be read from
   */
  private void readObject(java.io.ObjectInputStream input) {
    try {
      if (ticketList != null) {
        return;
      } else {
        input.defaultReadObject();
        if (ticketList == null) {
          ticketList = (TicketList) input.readObject();
        } else {
          input.readObject();
        }
      }
    } catch(IOException ioe) {
      ioe.printStackTrace();
    } catch(ClassNotFoundException cnfe) {
      cnfe.printStackTrace();
    }
  }
  /** String form of the collection
  * 
  */
  @Override
  public String toString() {
    return tickets.toString();
  }

}


