
/**
 * CustomerIDServer class keeps track of customer IDs
 * @author Gabriela, Safina, Mel
 * Cited Code:
 * Dathan B, Ramnath S. 24 Mar 2015. Source Code.  Class Project 2 Iteration 2.  
 * https://metrostate.learn.minnstate.edu/d2l/le/content/4940178/viewContent/43082126/View
 */
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.Serializable;

public class CustomerIDServer implements Serializable {

	private static final long serialVersionUID = 1L;
	private int idCounter;
	private static CustomerIDServer server;

	private CustomerIDServer() {
		idCounter = 1;
	}

	public static CustomerIDServer instance() {
		if (server == null) {
			return (server = new CustomerIDServer());
		} else {
			return server;
		}
	}

	public int getId() {
		return idCounter++;
	}

	public static void retrieve(ObjectInputStream input) {
		try {
			server = (CustomerIDServer) input.readObject();
		} catch (IOException ioe) {
			ioe.printStackTrace();
		} catch (Exception cnfe) {
			cnfe.printStackTrace();
		}
	}

	/*
	 * Supports deserialization
	 * 
	 * @param input the stream to be read from
	 */
	private void readObject(java.io.ObjectInputStream input) throws IOException, ClassNotFoundException {
		try {
			input.defaultReadObject();
			if (server == null) {
				server = (CustomerIDServer) input.readObject();
			} else {
				input.readObject();
			}
		} catch (IOException ioe) {
			ioe.printStackTrace();
		}
	}

	/*
	 * Supports serialization
	 * 
	 * @param output the stream to be written to
	 */
	private void writeObject(java.io.ObjectOutputStream output) throws IOException {
		try {
			output.defaultWriteObject();
			output.writeObject(server);
		} catch (IOException ioe) {
			ioe.printStackTrace();
		}
	}

}
