/**
 * StudentAdvanceTicket class hold info related to the purchase
 * of an advanced ticket
 * @author Gabriela, Safina, Mel
 */
import java.io.Serializable;

public class StudentAdvanceTicket extends Ticket implements Serializable {
	private int quantity;
	private String customerID;
	private String creditCardNum;
	private String showDate;
	String id;
	String ticketLabel;
	double price;
	private static final String TICKET_STRING = "C";
	private int advDays;

	
	/**
	 * Creates ticket that customer buys conceptually
	 * @param quantity
	 * @param customerID
	 * @param creditCardNum
	 * @param showDate 
	 * @param regPrice regular price of ticket
	 */
	public StudentAdvanceTicket(int quantity, String customerID, 
			String creditCardNum, String showDate,
			double regPrice) {
		super(quantity, customerID, creditCardNum, showDate, regPrice);
		this.customerID = super.getCustomerID();
		this.creditCardNum = super.getCreditCardNum();
		this.showDate = super.getShowDate();
		this.price = super.getPrice() * .5;

	}

	/**
	 * get price
	 * @return super.getPrice() * .50
	 */
	public double getPrice() {
		return super.getPrice() * .50;
	}

	/**
	 * updates price
	 */
	void updatePrice() {
		if (advDays >= 10) {
			price = 15.00;
		} else {
			price = 20.00;
		}
	}

	/**
	 * updates label
	 */
	void updateLabel() {
		ticketLabel = "Number: " + id + ", Price: " + price + "SEE ID";
	}

	/**
	 *@return super.getQuantity
	 */
	public int getQuantity() {
		return super.getQuantity();
	}

	/**
	 *@return return super.getCustomerID
	 */
	public String getCustomerID() {
		return super.getCustomerID();
	}

	/**
	 *sets customerId
	 *@param customerID
	 */
	public void setCustomerID(String customerID) {
		super.setCustomerID(customerID);
	}

	/**
	 *returns creditCardNum
	 *@return creditCardNum
	 */
	public String getCreditCardNum() {
		return super.getCreditCardNum();
	}

	/**
	 *gets show date
	 *@return showDate
	 */
	public String getShowDate() {
		return super.getShowDate();
	}

	/**
	 * @return the id
	 */
	public String getId() {
		return super.getId();
	}

	/*
	 * represents the string representation of the ticket object
	 * 
	 * @param returns the string representation
	 */

	@Override
	public String toString() {
		return super.toString();
	}

}
