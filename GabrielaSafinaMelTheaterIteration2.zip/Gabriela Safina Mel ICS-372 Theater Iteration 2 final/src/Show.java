/**
 * Show class holds info on show being booked
 * @author Gabriela, Safina, Mel
 * Cited Code:
 * Dathan B, Ramnath S. 24 Mar 2015. Source Code.  Class Project 2 Iteration 2.  
 * https://metrostate.learn.minnstate.edu/d2l/le/content/4940178/viewContent/43082126/View
 */
import java.io.Serializable;
import java.util.Iterator;
import java.util.LinkedList;

public class Show implements Serializable {
	private static final long serialVersionUID = 1L;
	private String showName = "";
	private String clientID;
	private String dateRange;
	private double regPrice;
	private LinkedList<Show> listOfShows = new LinkedList<Show>();

	/**
	 * Show() constructor Creates a show with a name, ID, and start/end date
	 * 
	 * @param showName  name of the show
	 * @param clientID  unique ID of client
	 * @param dateRange is the range of dates for show
	 */
	public Show(String showName, String clientID, String dateRange, double regPrice) {
		super();
		this.showName = showName;
		this.clientID = clientID;
		this.dateRange = dateRange;
		this.regPrice = regPrice;
	}

	/**
	 * getShowName() retrieves name of show
	 * 
	 * @return showName title of show
	 */
	public String getShowName() {
		return showName;
	}
	/**
	 * setShowName() sets the name of the show
	 * @param showName show title passed in
	 */
	public void setShowName(String showName) {
		this.showName = showName;
	}
	/**
	 * getRegPrice() gets regular price of ticket
	 * @return regPrice regular price of ticket
	 */
	public double getRegPrice() {
		return regPrice;
	}

	/**
	 * getShowName() retrieves clientID
	 * 
	 * @return clientID ID of client
	 */
	public String getClientID() {
		return clientID;
	}
	/**
	 * setClientID() 
	 * @param clientID id of client
	 */
	public void setClientID(String clientID) {
		this.clientID = clientID;
	}

	/**
	 * getShowName() retrieves dateRange
	 * 
	 * @return dateRange date range of play
	 */
	public String getStartDate() {
		return dateRange;
	}

	public void setStartDate(String dateRange) {
		this.dateRange = dateRange;
	}

	/**
	 * getSerialversionuid() gets the id
	 * 
	 * @return serialVersionUID
	 */
	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	/**
	 * Checks whether a client with a given client id exists.
	 * 
	 * @param clientId the id of the client
	 * @return true iff client exists
	 * 
	 */

	public Show search(String clientId) {
		for (Iterator<Show> iterator = listOfShows.iterator(); iterator.hasNext();) {
			Show show = (Show) iterator.next();
			if (show.getShowName().equals(clientId)) {
				return show;
			}
		}
		return null;
	}

	@Override
	public String toString() {
		return "\n" + "Shows name: " + showName + 
				"\t Client ID: " + clientID + "\t Date Range: " + dateRange + "\n";
	}

}
